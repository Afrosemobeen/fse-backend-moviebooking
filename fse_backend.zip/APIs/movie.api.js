const exp = require('express')
const movieApp = exp.Router()

const{getMovie,searchMovie,deleteMovie, addMovie, updateTicketStatus}=require('../controllers/movie.controller')

const {verifyToken} = require('../utils/auth')
movieApp.get('/all',getMovie)
movieApp.get('/movies/search/:moviename',searchMovie)
movieApp.delete('/delete/:moviename',verifyToken,deleteMovie)
movieApp.post('/add',verifyToken,addMovie) 
movieApp.post('/update/:title',verifyToken,updateTicketStatus)

module.exports=movieApp