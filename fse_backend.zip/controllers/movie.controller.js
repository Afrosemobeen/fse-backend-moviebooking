const {Movie} = require('../models/movie.model')

const getMovie = async(req,res)=>{
    try{
    const movie = await Movie.find()
    res.status(200).send({message:'Working',payload:movie})
}
catch(error){
    res.status(500).send(error)
 }
}
const searchMovie = async(req,res)=>{
    try{
    const regex = new RegExp(req.params.moviename,'i')
    const movie = await Movie.find({title:regex})
    res.status(200).send({message:'Working',payload:movie})
}
catch(error){
    res.status(500).send(error)
 }
}
const deleteMovie = async(req,res)=>{
    try{
    const title = req.body.moviename
    // const id = parseInt(req.params.id)
    // console.log('params',req.params,title,id)
    const movie = await Movie.deleteOne({title:title})
        
    res.status(200).send({message:'Movie deleted',payload:movie})
}
catch(error){
    res.status(500).send(error)
 }
}
const addMovie = async(req,res)=>{
    try{
    const{title,theatre,totaltickets,img,price}=req.body;
    let movie = await Movie.create({title,theatre,totaltickets,availabletickets:totaltickets,img,price})
res.status(200).send({message:'Added movie successfully'})
}
catch(error){
    res.status(500).send(error)
 }
}
const updateTicketStatus = async(req,res)=>{
    try{
    const{title}=req.params;
    const {ticket} = req.body;
    console.log('title',title)
    let movie = await Movie.findOne({title:title});
    console.log('title',movie)
if(!movie){
    return res.status(404).send({message:'Movie not found'})

}
    movie.availabletickets -=ticket;
movie.availabletickets= movie.availabletickets<=0?movie.status='SOLD OUT':movie.status='BOOK ASAP'
await Movie.updateOne({title:title},movie)
res.status(200).send({payload:'updated successfuly'})
}
catch(error){
    res.status(500).send(error)
 }
}
module.exports={updateTicketStatus,getMovie,searchMovie,deleteMovie,addMovie}